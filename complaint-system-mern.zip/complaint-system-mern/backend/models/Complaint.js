const mongoose = require('mongoose');
const ComplaintSchema = new mongoose.Schema({
  userId: mongoose.Schema.Types.ObjectId,
  title: String,
  description: String,
  address: String,
  purchaseDate: Date,
  status: { type: String, default: 'Pending' },
  agentId: mongoose.Schema.Types.ObjectId,
  messages: [
    {
      sender: String,
      text: String,
      timestamp: { type: Date, default: Date.now },
    }
  ]
});
module.exports = mongoose.model('Complaint', ComplaintSchema);