const express = require('express');
const Complaint = require('../models/Complaint');
const router = express.Router();

router.post('/', async (req, res) => {
  const complaint = new Complaint(req.body);
  await complaint.save();
  res.status(201).json(complaint);
});

router.get('/:userId', async (req, res) => {
  const complaints = await Complaint.find({ userId: req.params.userId });
  res.json(complaints);
});

router.put('/:id/status', async (req, res) => {
  const complaint = await Complaint.findByIdAndUpdate(
    req.params.id,
    { status: req.body.status },
    { new: true }
  );
  res.json(complaint);
});

module.exports = router;