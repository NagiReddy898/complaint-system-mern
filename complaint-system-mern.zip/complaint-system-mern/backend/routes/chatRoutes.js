const express = require('express');
const Complaint = require('../models/Complaint');
const router = express.Router();

router.post('/:id/message', async (req, res) => {
  const { sender, text } = req.body;
  const complaint = await Complaint.findById(req.params.id);
  complaint.messages.push({ sender, text });
  await complaint.save();
  res.json(complaint);
});

module.exports = router;