import React from 'react';

const Dashboard = () => {
  const user = JSON.parse(localStorage.getItem('user'));
  return <div>Welcome, {user?.name}! Role: {user?.role}</div>;
};
export default Dashboard;